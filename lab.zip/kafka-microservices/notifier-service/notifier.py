from kafka import KafkaConsumer
import json
import time
import redis
import socketio

# Kết nối Redis
r = redis.Redis(host='redis', port=6379, decode_responses=True)

# Kết nối WebSocket tới Flask UI
sio = socketio.Client()

while True:
    try:
        sio.connect('http://frontend-flask:8000')
        print("✅ Connected to Web UI via WebSocket")
        break
    except Exception as e:
        print(f"❌ Waiting for frontend WebSocket... {e}")
        time.sleep(3)

# Kết nối Kafka
while True:
    try:
        consumer = KafkaConsumer(
            'payment.success',
            'inventory.reserved',
            bootstrap_servers='kafka:9092',
            auto_offset_reset='earliest',
            group_id='notifier-group',
            value_deserializer=lambda m: json.loads(m.decode('utf-8'))
        )
        print("✅ Connected to Kafka broker")
        break
    except Exception as e:
        print(f"❌ Waiting for Kafka... {e}")
        time.sleep(5)

print("📢 Notifier Service listening for events...")

for msg in consumer:
    data = msg.value
    topic = msg.topic
    order_id = str(data['order_id'])

    print(f"📥 Received on [{topic}]: order_id={order_id}")

    r.set(f"{order_id}:{topic}", "1", ex=300)  # TTL 5 phút

    # Kiểm tra nếu đã có cả 2 event
    if r.get(f"{order_id}:payment.success") and r.get(f"{order_id}:inventory.reserved"):
        notify_msg = f"✅ Order {order_id} is ready to ship!"
        print(notify_msg)
        sio.emit('order_ready', {'message': notify_msg})
        # Dọn dẹp
        r.delete(f"{order_id}:payment.success")
        r.delete(f"{order_id}:inventory.reserved")

