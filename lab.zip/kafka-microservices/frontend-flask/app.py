from flask import Flask, render_template, request, redirect
from flask_socketio import SocketIO
import requests

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/submit_order', methods=['POST'])
def submit_order():
    order_id = request.form['order_id']
    item = request.form['item']
    quantity = request.form['quantity']

    data = {
        "order_id": int(order_id),
        "item": item,
        "quantity": int(quantity)
    }

    try:
        # Gửi dữ liệu tới order-service
        res = requests.post('http://order-service:5000/create_order', json=data)
        print(f"✅ Order submitted: {data}")
    except Exception as e:
        print("❌ Failed to submit order:", e)

    return redirect('/')

# Nhận sự kiện từ notifier-service qua WebSocket
@socketio.on('order_ready')
def handle_order_ready(data):
    print("📢 Received from notifier-service:", data)
    socketio.emit('order_ready', data)  # Không dùng broadcast

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=8000)

