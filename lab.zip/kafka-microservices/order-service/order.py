from flask import Flask, request, jsonify
from kafka import KafkaProducer
import json
import time
import requests

app = Flask(__name__)
producer = None

# Retry logic to wait for Kafka
for i in range(5):
    try:
        producer = KafkaProducer(
            bootstrap_servers='kafka:9092',
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        print("✅ Connected to Kafka broker.")
        break
    except Exception as e:
        print(f"❌ Kafka not ready, retrying in 5s... ({e})")
        time.sleep(5)

@app.route('/create_order', methods=['POST'])
def create_order():
    data = request.json
    print(f"✅ Order submitted: {data}")

    # Push to Kafka topic
    producer.send('order.created', data)

    # Push log to Elasticsearch
    try:
        resp = requests.post("http://elasticsearch:9200/order-logs/_doc", json={
            "order_id": data.get("order_id"),
            "item": data.get("item"),
            "quantity": data.get("quantity"),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
        })
        print(f"📤 Log pushed to Elasticsearch: {resp.status_code}")
    except Exception as e:
        print(f"❌ Failed to send log to ES: {e}")

    return jsonify({"message": "Order created"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

