from kafka import KafkaConsumer, KafkaProducer
import json
import time

# Chờ Kafka sẵn sàng
while True:
    try:
        consumer = KafkaConsumer(
            'order.created',
            bootstrap_servers='kafka:9092',
            auto_offset_reset='earliest',
            group_id='inventory-service',
            value_deserializer=lambda m: json.loads(m.decode('utf-8'))
        )
        producer = KafkaProducer(
            bootstrap_servers='kafka:9092',
            value_serializer=lambda m: json.dumps(m).encode('utf-8')
        )
        print("✅ Inventory Service connected to Kafka.")
        break
    except Exception as e:
        print(f"❌ Kafka not ready for Inventory Service, retrying in 5s... ({e.__class__.__name__})")
        time.sleep(5)

print("📦 Inventory Service listening for 'order.created' events...")

for msg in consumer:
    order = msg.value
    order_id = order['order_id']
    item = order['item']
    quantity = order['quantity']

    print(f"📦 [INVENTORY] Deducting stock for order {order_id} - Item: {item} x{quantity}")

    event = {"order_id": order_id}
    producer.send('inventory.reserved', value=event)
    producer.flush()

