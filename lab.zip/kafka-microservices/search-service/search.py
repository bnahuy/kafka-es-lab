from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

@app.route('/search')
def search():
    item = request.args.get("item")
    if not item:
        return jsonify({"error": "Missing 'item' query param"}), 400

    es_url = "http://elasticsearch:9200/order-logs/_search"
    query = {
        "query": {
            "match": {
                "item": item
            }
        }
    }

    try:
        res = requests.get(es_url, json=query)
        hits = res.json().get('hits', {}).get('hits', [])
        results = [hit['_source'] for hit in hits]
        return jsonify(results)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5100)

